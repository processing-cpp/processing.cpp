# processing-cpp (CMake package)

This is [Processing](https://processing.org)'s API -- `size()`, `ellipse()`,
`mouseX`, `draw()`, and the rest of it -- implemented natively in C++,
packaged as a normal CMake target. There's no Processing IDE involved, no
`.pde` files, and no transpiler.

If you're not using CMake, there's a separate drag-and-drop release built
for that instead -- look for `processing-cpp-dragdrop.zip` on the same
page you got this from, or in the
[CppMode repo](https://github.com/processing-cpp/processing.cpp). That one
needs no build system at all; this one assumes you already have CMake.

## Writing a sketch

```cpp
#include "Processing.h"

struct Sketch : public Processing::PApplet {
    void settings() override { size(640, 360); }
    void setup()    override { background(0); }
    void draw()     override {
        background(0);
        fill(255, 140, 0);
        circle(mouseX, mouseY, 40);
    }
};

int main() {
    Sketch sketch;
    sketch.run();
    return 0;
}
```

You inherit from `PApplet`, override whichever lifecycle methods you need,
and call `.run()` in `main()`. Everything in the
[Processing reference](https://processing.org/reference) is available as
a member you inherit, so it's unqualified inside your overrides -- no
`Processing::` prefix needed there. A helper class that *isn't* a
`PApplet` (e.g. a `Particle`) needs one `using namespace Processing;` near
the top of its own file to call these -- `examples/embedding/` shows this.

## Adding it to your project

Pick whichever of these matches how you manage dependencies. All three
end up giving you the same `processing_cpp` CMake target, with
GLFW/GLEW/OpenGL discovery and every platform-specific link flag
(`-framework OpenGL` on macOS, `-mwindows` on Windows, and so on) already
attached to it -- so the rest of your `CMakeLists.txt` doesn't need to
know any of that exists.

### Vendored: copy this folder into your repo

```cmake
add_subdirectory(processing-cpp)
target_link_libraries(my_sketch PRIVATE processing_cpp)
```

### FetchContent: no copying, CMake fetches it for you

```cmake
include(FetchContent)
FetchContent_Declare(processing_cpp
    GIT_REPOSITORY https://github.com/processing-cpp/processing-cpp-lib.git
    GIT_TAG main
)
FetchContent_MakeAvailable(processing_cpp)

add_executable(my_sketch main.cpp)
target_link_libraries(my_sketch PRIVATE processing_cpp)
```

### Installed system-wide

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
sudo cmake --install build
```

```cmake
find_package(processing_cpp REQUIRED)
target_link_libraries(my_sketch PRIVATE processing_cpp)
```

## Dependencies

GLFW3, GLEW, OpenGL, and a C++17 compiler. CMake looks for them with
`find_package`/`pkg-config` first, so if you already have them installed,
nothing else happens:

```sh
# Ubuntu / Debian
sudo apt install libglfw3-dev libglew-dev

# Arch
sudo pacman -S glfw glew

# macOS (Homebrew)
brew install glfw glew

# Windows, via MSYS2
pacman -S mingw-w64-x86_64-glfw mingw-w64-x86_64-glew
```

If you'd rather not install them yourself, configure with
`-DPROCESSING_CPP_FETCH_DEPS=ON` and CMake will build GLFW and GLEW from
source automatically as part of your build. This is off by default
because building two extra libraries from source on someone's first
`cmake configure` can be a surprising thing to have happen silently.

## The two examples included here

```sh
cmake -S . -B build
cmake --build build -j
./build/examples/bouncing_ball
```

- **`examples/bouncing_ball.cpp`** is the sketch shown above, with a
  little more in it -- an orange ball bouncing around the window.
- **`examples/embedding/`** shows how to drop a sketch into a project
  that already exists, without the rest of that project ever needing to
  know GLFW, GLEW, or `PApplet` exist. The `PApplet` subclass and the
  `#include "Processing.h"` live only inside `app.cpp`; `main.cpp` only
  sees `app.h`'s plain `run_particle_view()` function. Built as
  `embedded_sketch` by the same `cmake --build` above.

## Where this comes from

This release is built by `scripts/generate_cmake.py` in the main
[CppMode repo](https://github.com/processing-cpp/processing.cpp), and it's
generated directly from that repo's real engine source
(`src/Processing.h`, `src/Processing.cpp`) -- the very same code CppMode's
Processing IDE plugin compiles your sketches against.
