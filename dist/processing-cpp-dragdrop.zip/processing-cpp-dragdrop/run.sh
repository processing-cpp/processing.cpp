#!/usr/bin/env bash
# Builds and runs your sketch -- the one command this whole package is
# built around. Finds your .cpp file(s) one directory up (wherever you
# dropped this processing-cpp/ folder), compiles, links, and runs.
#
# Usage:
#   ./processing-cpp/run.sh                  # auto-detects .cpp files next to this folder
#   ./processing-cpp/run.sh main.cpp app.cpp # explicit, e.g. a multi-file sketch
#
# The engine itself is compiled once and cached in processing-cpp/lib/ --
# only your own file(s) get recompiled on later runs, unless the engine
# source in this folder changes (e.g. you updated the package).
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_DIR"

if [ "$#" -gt 0 ]; then
    SOURCES=("$@")
else
    SOURCES=()
    while IFS= read -r -d '' f; do
        SOURCES+=("$f")
    done < <(find . -maxdepth 1 -name '*.cpp' -print0)

    if [ "${#SOURCES[@]}" -eq 0 ]; then
        echo "error: no .cpp files found in $PROJECT_DIR" >&2
        echo "Put your sketch's .cpp file next to the processing-cpp/ folder, or run:" >&2
        echo "  processing-cpp/run.sh path/to/your_file.cpp" >&2
        exit 1
    fi
fi

echo "Building: ${SOURCES[*]}"

OS="$(uname -s)"
case "$OS" in
    Darwin)
        GL_LIBS=(-lglfw -lGLEW -framework OpenGL -framework Cocoa -framework IOKit -framework CoreVideo)
        ;;
    Linux)
        GL_LIBS=(-lglfw -lGLEW -lGL -lGLU -lm -pthread)
        ;;
    *)
        echo "error: unrecognized OS '$OS' -- on Windows, use run.bat instead" >&2
        exit 1
        ;;
esac

ENGINE_DIR="$SCRIPT_DIR"
LIB_DIR="$ENGINE_DIR/lib"
LIB_A="$LIB_DIR/libprocessing_cpp.a"
mkdir -p "$LIB_DIR"

NEED_ENGINE_BUILD=0
if [ ! -f "$LIB_A" ]; then
    NEED_ENGINE_BUILD=1
else
    for src in "$ENGINE_DIR/src/Processing.cpp" "$ENGINE_DIR/src/Processing_defaults.cpp"; do
        if [ "$src" -nt "$LIB_A" ]; then
            NEED_ENGINE_BUILD=1
        fi
    done
fi

if [ "$NEED_ENGINE_BUILD" -eq 1 ]; then
    echo "Compiling engine (first run, or engine source changed; ~10-15s)..."
    g++ -std=c++17 -O2 -c -I"$ENGINE_DIR/include" \
        -DPROCESSING_HAS_STB_IMAGE -DPROCESSING_HAS_STB_TRUETYPE \
        "$ENGINE_DIR/src/Processing.cpp" -o "$LIB_DIR/Processing.o"
    g++ -std=c++17 -O2 -c -I"$ENGINE_DIR/include" \
        -DPROCESSING_HAS_STB_IMAGE -DPROCESSING_HAS_STB_TRUETYPE \
        "$ENGINE_DIR/src/Processing_defaults.cpp" -o "$LIB_DIR/Processing_defaults.o"
    ar rcs "$LIB_A" "$LIB_DIR/Processing.o" "$LIB_DIR/Processing_defaults.o"
    rm -f "$LIB_DIR/Processing.o" "$LIB_DIR/Processing_defaults.o"
fi

OUT="$PROJECT_DIR/.processing-cpp-build"
g++ -std=c++17 -I"$ENGINE_DIR/include" "${SOURCES[@]}" \
    -L"$LIB_DIR" -lprocessing_cpp "${GL_LIBS[@]}" \
    -o "$OUT"

echo "Running..."
exec "$OUT"
