@echo off
REM Builds and runs your sketch -- the one command this package is built
REM around. Finds your .cpp file(s) one directory up (wherever you dropped
REM this processing-cpp folder), compiles, links, and runs. Requires
REM MSYS2 (g++, ar) on PATH.
REM
REM Usage:
REM   processing-cpp\run.bat
REM   processing-cpp\run.bat main.cpp app.cpp
setlocal enabledelayedexpansion

set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%\.."
set "PROJECT_DIR=%CD%"

set "SOURCES=%*"
if "%SOURCES%"=="" (
    set "SOURCES="
    for %%f in (*.cpp) do set "SOURCES=!SOURCES! %%f"
)
if "%SOURCES%"=="" (
    echo error: no .cpp files found in %PROJECT_DIR%
    echo Put your sketch's .cpp file next to the processing-cpp folder, or run:
    echo   processing-cpp\run.bat path\to\your_file.cpp
    exit /b 1
)

echo Building: %SOURCES%

set "ENGINE_DIR=%SCRIPT_DIR%"
set "LIB_DIR=%ENGINE_DIR%lib"
set "LIB_A=%LIB_DIR%\libprocessing_cpp.a"
if not exist "%LIB_DIR%" mkdir "%LIB_DIR%"

set NEED_ENGINE_BUILD=0
if not exist "%LIB_A%" set NEED_ENGINE_BUILD=1

if %NEED_ENGINE_BUILD%==1 (
    echo Compiling engine ^(first run; ~10-15s^)...
    g++ -std=c++17 -O2 -c -I"%ENGINE_DIR%include" -DPROCESSING_HAS_STB_IMAGE -DPROCESSING_HAS_STB_TRUETYPE -D_USE_MATH_DEFINES "%ENGINE_DIR%src\Processing.cpp" -o "%LIB_DIR%\Processing.o"
    if errorlevel 1 exit /b 1
    g++ -std=c++17 -O2 -c -I"%ENGINE_DIR%include" -DPROCESSING_HAS_STB_IMAGE -DPROCESSING_HAS_STB_TRUETYPE -D_USE_MATH_DEFINES "%ENGINE_DIR%src\Processing_defaults.cpp" -o "%LIB_DIR%\Processing_defaults.o"
    if errorlevel 1 exit /b 1
    ar rcs "%LIB_A%" "%LIB_DIR%\Processing.o" "%LIB_DIR%\Processing_defaults.o"
    del "%LIB_DIR%\Processing.o" "%LIB_DIR%\Processing_defaults.o"
)

g++ -std=c++17 -I"%ENGINE_DIR%include" %SOURCES% -L"%LIB_DIR%" -lprocessing_cpp -lglfw3 -lglew32 -lopengl32 -lglu32 -lcomdlg32 -lshell32 -lole32 -luuid -mwindows -pthread -D_USE_MATH_DEFINES -o "%PROJECT_DIR%\.processing-cpp-build.exe"
if errorlevel 1 exit /b 1

echo Running...
"%PROJECT_DIR%\.processing-cpp-build.exe"
